const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const session = require('express-session');
const cookieParser = require('cookie-parser');

const css = require('./web/web/css.js');
const js = require('./web/web/js.js');
const vendor = require('./web/web/vendor.js');


const registerToken = require('./ganglion/register/index.js');


const weblogin = require('./web/login.js');
const webregister = require('./web/user/register.js');
const webMain = require('./web/main/index.js');
const webProfile = require('./web/profile/index.js');
const webRegisterEOG = require('./web/profile/register.js');


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(session({
	secret: 'secret key',
	resave: false,
	saveUninitialized: true
}));
app.use(cookieParser());


app.use('/ganglion/index', registerToken);

//css, js, vendor 설정
app.use('/web/css', css);
app.use('/web/js', js);
app.use('/web/vendor', vendor);
app.use('/web/user/css', css);
app.use('/web/user/js', js);
app.use('/web/user/vendor', vendor);
app.use('/web/main/css', css);
app.use('/web/main/js', js);
app.use('/web/main/vendor', vendor);
app.use('/web/profile/css', css);
app.use('/web/profile/js', js);
app.use('/web/profile/vendor', vendor);


app.use('/web/login', weblogin);
app.use('/web/user/register', webregister);
app.use('/web/main/index', webMain);
app.use('/web/profile/index', webProfile);
app.use('/web/profile/register', webRegisterEOG);


app.listen(65002, () => {
	console.log("server running at http://192.9.45.80:65002");
});
