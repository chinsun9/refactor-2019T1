const express = require('express');
const router = express.Router();
const gpio = require('node-wiring-pi');
const mysql = require('sync-mysql');

const client = new mysql({
        host: 'localhost',
        user: 'root',
        password: 'gachon654321',
        database: 'luciddb'
});

const LED1 = 27;
const LED2 = 28;
const LED3 = 29;

var checkLogin = false;
var userNum;
var userNum_fp2;
var checkLogin_fp2 = false;
//fp1 데이터
var temp = new Array();
//fp2 데이터
var temp_fp2 = new Array();

router.post('/', (req, res) => {
  var fp1 = login(req.body.TwoY);
  var fp2 = login_fp2(req.body.ThreeY);
  if(checkLogin == false || checkLogin_fp2 == false){
    res.writeHead(200, {'Content-Type': 'text/html; charset=utf8'});
    res.end("데이터 재 전송 요청..");
  }
  else if(checkLogin == true && checkLogin_fp2 == true && userNum == userNum_fp2){
    var query_user = "SELECT * FROM USER WHERE userNum = " + userNum;
    var result_user = client.query(query_user);
    res.writeHead(200, {'Content-Type': 'text/html; charset=utf8'});
    res.write(result_user[0].userName);
    res.end(result_user[0].userId);
    gpio.digitalWrite(LED2, 1);
    gpio.digitalWrite(LED3, 1);
    gpio.digitalWrite(LED1, 1);
    setTimeout(TurnOff, 1000);
    checkLogin = false;
    checkLogin_fp2 = false;
  }
  else{
    res.writeHead(200, {'Content-Type': 'text/html; charset=utf8'});
    res.end("5");
  }
});

function login(fpdata) {
  let TwoY = null;
  TwoY = fpdata;
  console.log("TwoY 배열크기" + TwoY.length);

  // 처음 배열을 받는다면 temp로 덮어쓰고 종료
  if (temp.length == 0) {
      // 깊은 복사

      temp = JSON.parse(JSON.stringify(TwoY));
      console.log('first input!');
      return 0
      // 코드종료
  }
  else{
  var range = 700;
  var chkNum = 5;
  let check1 = 0;

  for (let i = temp.length - 1; i >= temp.length - range; i--) {

    // console.log(i+"안녕"+temp.length);
      if (isVaild(i, TwoY, chkNum)) {
          check1 = 1;
          console.log('배열 합치기 성공');
          temp.splice(i - chkNum, range);
          var result = temp.concat(TwoY);
          temp= [];
          break;
      }
      // console.log("성재바보");
    }
    if (check1 == 0) {
        console.log("실패")
        gpio.digitalWrite(LED2, 1);
        setTimeout(TurnOff, 1000);
        temp =  [];
        return 0

    }
    else{

        var checkPoint1 = 0;
        var checkPoint2 = 0;
        var checkPoint3 = 0;
        var check = 0;
        var flag1 = 0;
        //console.log(TwoY);
        // console.log(typeof (TwoY));

        for (let i = 0; i < result.length; i++) {
            if (result[i] <= 70 && flag1 == 0) {
                for (let j = i; result[j] <= 100; j--) {
                    if (result[j] >= 100) {
                        checkPoint1 = j;
                        flag1 = 1;
                        console.log('z');
                        break;
                    }
                }
            }
            // console.log("2");
            if (flag1 == 1 && result[i] >= 100) {
                console.log('qq');
                flag1 = 2;
                checkPoint2 = i;
            }
            if (flag1 == 2 && result[i] <= 100 && checkPoint2 + 10 < i) {
                checkPoint3 = i;
                break;
            }
        }
        console.log(checkPoint1 + "   " + checkPoint2 + "   " + checkPoint3);

        if(checkPoint1 != 0 && checkPoint2 != 0 && checkPoint3 != 0){
          var checkLoginOk = g1forCheck(result.slice( checkPoint1, checkPoint3 ));
          return checkLoginOk
        }
        else{
          gpio.digitalWrite(LED1, 1);
          setTimeout(TurnOff, 1000);
        }

      temp = JSON.parse(JSON.stringify(TwoY));

      //console.log("첫쨰배열크기" + temp.length);
      //console.log("합쳐진 크기" + result.length);
      return 0
      }
    }
  }

function login_fp2(fpdata) {
  let ThreeY = null;
  ThreeY = fpdata;
  console.log("ThreeY 배열크기" + ThreeY.length);

  // 처음 배열을 받는다면 temp_fp2로 덮어쓰고 종료
  if (temp_fp2.length == 0) {
      // 깊은 복사

      temp_fp2 = JSON.parse(JSON.stringify(ThreeY));
      console.log('first input!');
      return 0
      // 코드종료
  }
  else {

  var range = 700;
  var chkNum = 5;
  let check1 = 0;

  for (let i = temp_fp2.length - 1; i >= temp_fp2.length - range; i--) {

    // console.log(i+"안녕"+temp_fp2.length);
      if (isVaild_fp2(i, ThreeY, chkNum)) {
          check1 = 1;
          console.log('배열 합치기 성공');
          temp_fp2.splice(i - chkNum, range);
          var result = temp_fp2.concat(ThreeY);
          temp_fp2= [];
          break;
      }
      // console.log("성재바보");
  }
    if (check1 == 0) {
        console.log("실패")
        gpio.digitalWrite(LED2, 1);
        setTimeout(TurnOff, 1000);
        temp_fp2 =  [];
        return 0

    }
    else{
      // console.log("1");

      var checkPoint1 = 0;
      var checkPoint2 = 0;
      var checkPoint3 = 0;
      var check = 0;
      var flag1 = 0;
      //console.log(ThreeY);
      // console.log(typeof (ThreeY));

      for (let i = 0; i < result.length; i++) {
          if (result[i] <= 70 && flag1 == 0) {
              for (let j = i; result[j] <= 100; j--) {
                  if (result[j] >= 100) {
                      checkPoint1 = j;
                      flag1 = 1;
                      console.log('z');
                      break;
                  }
              }
          }
          // console.log("2");
          if (flag1 == 1 && result[i] >= 100) {
              console.log('qq');
              flag1 = 2;
              checkPoint2 = i;
          }
          if (flag1 == 2 && result[i] <= 100 && checkPoint2 + 10 < i) {
              checkPoint3 = i;
              break;
          }
      }
      console.log(checkPoint1 + "   " + checkPoint2 + "   " + checkPoint3);

      if(checkPoint1 != 0 && checkPoint2 != 0 && checkPoint3 != 0){
            var checkLoginOk_fp2 = g1forCheck_fp2(result.slice( checkPoint1, checkPoint3 ));
            return checkLoginOk_fp2
      }
    else{
      gpio.digitalWrite(LED1, 1);
      setTimeout(TurnOff, 1000);
    }
      // 추출끝나면 temp_fp2로 덮어쓰기
    temp_fp2 = JSON.parse(JSON.stringify(ThreeY));

    //console.log("첫쨰배열크기" + temp_fp2.length);
    //console.log("합쳐진 크기" + result.length);
    return 0
    }
  }
}

function g1forCheck (y) {
	let max = 100; let maxX = 0;
	let min = 100; let minX = 0;
	var a = "";
	for(let i = 0; i < y.length; i++) {
		if(max > y[i]) {
			max = y[i];
			maxX = i;
		}
	}

	for(let i = 0; i < y.length; i++) {
		if(min < y[i]) {
			min = y[i];
			minX = i;
		}
	}

	let ip = maxX;
	let in1 = 0;

	let check = 0;
	for(let i = 0; i < y.length; i++) {
		if(i > maxX + 2 && y[i] >= 100) {
			in1 = minX - i;
			console.log("aa");
			//in1 = j;
			check = 1;
			break;
		}
		if(check == 1)
			break;
	}

	in1 = minX - in1;

  var query = "SELECT userNum FROM LOGINEOGFP1 WHERE " + max + " BETWEEN mpMin - 5 AND mpMax + 5 AND " + min + " BETWEEN mnMin - 5 AND mnMax + 5 AND "+ ip +" BETWEEN ipMin - 5 AND ipMax + 5 AND " + in1 + " BETWEEN inMin - 5 AND inMax + 5";
  var result = client.query(query);
  console.log(result.length);
  console.log("dd" + max + min + ip + in1);
  if(result.length == 0){
    return 5;
  }
  else {
    checkLogin = true;
    userNum = result[0].userNum;
    return result[0].userNum;
  }
}

function g1forCheck_fp2 (y) {
	let max = 100; let maxX = 0;
	let min = 100; let minX = 0;
	var a = "";
	for(let i = 0; i < y.length; i++) {
		if(max > y[i]) {
			max = y[i];
			maxX = i;
		}
	}

	for(let i = 0; i < y.length; i++) {
		if(min < y[i]) {
			min = y[i];
			minX = i;
		}
	}

	let ip = maxX;
	let in1 = 0;

	let check = 0;
	for(let i = 0; i < y.length; i++) {
		if(i > maxX + 2 && y[i] >= 100) {
			in1 = minX - i;
			console.log("aa");
			//in1 = j;
			check = 1;
			break;
		}
		if(check == 1)
			break;
	}

	in1 = minX - in1;
  var query_fp2 = "SELECT userNum FROM LOGINEOGFP2 WHERE " + max + " BETWEEN mpMin - 5 AND mpMax + 5 AND " + min + " BETWEEN mnMin - 5 AND mnMax + 5 AND "+ ip +" BETWEEN ipMin - 5 AND ipMax + 5 AND " + in1 + " BETWEEN inMin - 5 AND inMax + 5";
  var result_fp2 = client.query(query_fp2);
  console.log("dd" + max + min + ip + in1);
  if(result_fp2.length == 0){
    console.log(result_fp2.length);
    return 5;
  }
  else {
    checkLogin_fp2 = true;
    userNum_fp2 = result_fp2[0].userNum;
    return result_fp2[0].userNum;
  }
}

const isVaild = (x, TwoY, range) => {
		let tol = 1;
    for (let i = 0; i < range; i++) {
        if (temp[x - i] >= TwoY[range - i] -2 && temp[x - i] <= TwoY[range - i] +2) {
            ;
        }
        else {
            return false;
        }
    }
    return true;
}

const isVaild_fp2 = (x, ThreeY, range) => {
		let tol = 1;
    for (let i = 0; i < range; i++) {
        if (temp_fp2[x - i] >= ThreeY[range - i] -2 && temp_fp2[x - i] <= ThreeY[range - i] +2) {
            ;
        }
        else {
            return false;
        }
    }
    return true;
}

const TurnOff = () => {

	gpio.digitalWrite(LED1, 0);
  gpio.digitalWrite(LED2, 0);
  gpio.digitalWrite(LED3, 0);
}

gpio.setup('wpi');
gpio.pinMode(LED2, gpio.OUTPUT);
gpio.pinMode(LED3, gpio.OUTPUT);
gpio.pinMode(LED1, gpio.OUTPUT);

module.exports = router;
